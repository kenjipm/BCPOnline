function select_payment_method(name) {
	$("#payment_method-"+name).prop("checked", true);
}

function select_delivery_method(name) {
	$("#delivery_method-"+name).prop("checked", true);
}