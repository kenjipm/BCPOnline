
function add_variance(){ 

	var desc = $("#var_desc").val();
	var quantity_available = $("#quantity_available").val();
	
	$("#div_variance").find("[name='var_desc[]']").attr("value", desc);
	$("#div_variance").find("[name='quantity_available[]']").attr("value", quantity_available);
	
	var newdiv = $("#div_variance").html();
	
	$("#var_desc_list").append(newdiv);

}
