
function set_nego_price(){

	document.getElementById("add_customer").style.display = 'block';
	document.getElementById("add_price").style.display = 'none';

}
