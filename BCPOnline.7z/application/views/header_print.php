<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<html>
<head>
    <link rel='stylesheet' href='<?=site_url('css/bootstrap/css/bootstrap.min.css')?>' type='text/css'/>
    <link rel='stylesheet' href='<?=site_url('css/default.css')?>' type='text/css'/>
</head>
<body>
