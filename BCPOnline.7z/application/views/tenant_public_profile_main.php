<div class="row">
	<div class="col-md-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h3>Profil</h3>
			</div>
			<div class="panel-body">
				<div class="row">
					<div class="col-md-3">
						<div id="thumbnail-profile_pic" class="thumbnail">
							<img src="<?=$model->tenant->account->profile_pic?>" alt="<?=$model->tenant->tenant_name?>" style="width:100%">
						</div>
						<button type="button" class="btn btn-default col-md-12 <?= $model->tenant->btn_class ?>" id="btn-toggle_tenant_favorite" onclick="toggle_tenant_favorite(<?=$model->tenant->id?>)"><?= $model->tenant->btn_text ?></button>
						<form method="post" action="<?=site_url('message/open_detail_do')?>">
							<input type="hidden" name="receiver_account_id" value="<?=$model->tenant->account_id?>"/>
							<button type="submit" class="btn btn-default col-md-12" id="btn-send_message">Kirim Pesan</button>
						</form>
					</div>
					<div class="col-md-9">
						<div class="row"><?=$model->tenant->tenant_name?></div>
						<div class="row"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-md-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h3>Items</h3>
			</div>
			<div class="panel-body">
				<div class="row">
					<?php
					foreach($model->tenant->items as $tenant_item)
					{
						?>
							<div class="col-md-4">
								<div class="panel panel-default">
									<a href="<?=site_url('item/'.$tenant_item->id)?>">
										<div class="panel-body">
											<img class="col-md-12" src="<?=$tenant_item->image_one_name?>" alt="<?=$tenant_item->posted_item_name?>"/>
										</div>
										<div class="panel-footer">
											<label class="control-label"><?=$tenant_item->posted_item_name?></label><br/>
											<label class="control-label"><?=$tenant_item->price?></label>
										</div>
									</a>
								</div>
							</div>
						<?php
					}
					?>
				</div>
			</div>
		</div>
	</div>
</div>