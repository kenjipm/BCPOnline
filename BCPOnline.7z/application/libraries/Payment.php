<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Payment {
	
	public function insert_payment_klikbca()
	{
		
	}
}

?>