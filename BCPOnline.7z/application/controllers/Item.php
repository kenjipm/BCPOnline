<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Item extends CI_Controller {

	public function index($id) // load view item untuk customer
	{
		// Load Header
        $data_header['css_list'] = array();
        $data_header['js_list'] = array('toggle_tenant_favorite', 'toggle_item_favorite', 'item_main');
		$this->load->view('header', $data_header);
		
		// Load Body
		$this->load->model('item_model');
		$item = $this->item_model->get_from_id($id);
		
		$this->load->model('posted_item_variance_model');
		$item_variances = $this->posted_item_variance_model->get_all_from_posted_item_id($id);
		
		$item_main_view = $this->load->model('views/item_main_view_model');
		$this->item_main_view_model->get($item, $item_variances);
		
		$data['model'] = $this->item_main_view_model;
		$this->load->view('item_main', $data);
		
		// Load Footer
		$this->load->view('footer');
	}
	
	// Tenant View
	public function post_item()
	{
		// kalau create item baru
		if ($this->input->method() == "post") $this->post_item_do();
		
		// Load Header
        $data_header['css_list'] = array();
        $data_header['js_list'] = array("tenant/post_item_variance", "tenant/post_item");
		$this->load->view('header', $data_header);
		
		// Load Body
		$this->load->model('Category_model');
		$this->load->model('Brand_model');
		$categories = $this->Category_model->get_all();
		$brands = $this->Brand_model->get_all();
		$this->load->model('views/tenant/post_item_view_model');
		$this->post_item_view_model->get($categories, $brands);
		$data['model'] = $this->post_item_view_model;
		
		$this->load->view('tenant/post_item', $data);
		
		// Load Footer
		$this->load->view('footer');
	}
	
	public function post_item_list()
	{
		// Load Header
        $data_header['css_list'] = array();
        $data_header['js_list'] = array();
		$this->load->view('header', $data_header);
		
		// Load Body
		
		if ($this->session->userdata('type') == TYPE['name']['ADMIN'])
		{
			$this->load->model('Item_model');
			$items = $this->Item_model->get_all_for_admin();
			$this->load->model('views/admin/post_item_list_view_model');
			$this->post_item_list_view_model->get($items);
			$data['model'] = $this->post_item_list_view_model;
			
			$this->load->view('admin/post_item_list', $data);
		}
		else // TENANT
		{
			$this->load->model('Item_model');
			$items = $this->Item_model->get_all();
			$this->load->model('views/tenant/post_item_list_view_model');
			$this->post_item_list_view_model->get($items);
			$data['model'] = $this->post_item_list_view_model;
			
			$this->load->view('tenant/post_item_list', $data);
		}
		
		// Load Footer
		$this->load->view('footer');
	}
	
	public function post_item_detail($id)
	{		
		// Load Header
        $data_header['css_list'] = array();
        $data_header['js_list'] = array();
		$this->load->view('header', $data_header);
		
		// Load Body
		$this->load->model('Item_model');
		$this->load->model('Posted_item_variance_model');
		$item = $this->Item_model->get_from_id($id);
		$posted_item_variance = $this->Posted_item_variance_model->get_all($id);
		$this->load->model('views/tenant/post_item_detail_view_model');
		$this->post_item_detail_view_model->get($item, $posted_item_variance);
		$data['model'] = $this->post_item_detail_view_model;
		
		$this->load->view('tenant/post_item_detail', $data);
		
		// Load Footer
		$this->load->view('footer');
	}
	
	public function search()
	{
		// Load Header
        $data_header['css_list'] = array();
        $data_header['js_list'] = array();
		$this->load->view('header', $data_header);
		
		// Load Body
		$keywords = $this->input->get('keywords');
		
		$this->load->model('item_model');
		$items = $this->item_model->get_from_search($keywords);
		$this->load->model('views/search_view_model');
		$this->search_view_model->get($items);
		
		$data['title'] = 'Hasil Pencarian';
		$data['model'] = $this->search_view_model;
		$this->load->view('search', $data);
		
		// Load Footer
		$this->load->view('footer');
	}
	
	public function category($category_id)
	{
		// Load Header
        $data_header['css_list'] = array();
        $data_header['js_list'] = array();
		$this->load->view('header', $data_header);
		
		// Load Body
		$this->load->model('item_model');
		$items = $this->item_model->get_all_from_category_id($category_id);
		
		$this->load->model('category_model');
		$category = $this->category_model->get_from_id($category_id);
		
		$this->load->model('views/search_view_model');
		$this->search_view_model->get($items);
		
		$data['title'] = 'Kategori '.$category->category_name;
		$data['model'] = $this->search_view_model;
		$this->load->view('search', $data);
		
		// Load Footer
		$this->load->view('footer');
	}
	
	public function post_item_do()
	{
		$this->load->library('form_validation');

		if ($this->input->post('item_type') == "ORDER")
		{
			$this->form_validation->set_rules('posted_item_name', 'Nama', 'required');
			$this->form_validation->set_rules('price', 'Harga', 'required|integer');
			$this->form_validation->set_rules('item_type', 'Tipe', 'required');
			$this->form_validation->set_rules('quantity_avalaible', 'Jumlah Stok', 'integer');
			$this->form_validation->set_rules('unit_weight', 'Berat', 'integer');
			$this->form_validation->set_rules('posted_item_description', 'Deskripsi', 'required');
			$this->form_validation->set_rules('category_id', 'Kategori', 'required');
			$this->form_validation->set_rules('brand_id', 'Brand', 'required');
		} 
		else if ($this->input->post('item_type') == "REPAIR")
		{
			$this->form_validation->set_rules('posted_item_description', 'Deskripsi', 'required');
			$this->form_validation->set_rules('category_id', 'Kategori', 'required');
			$this->form_validation->set_rules('brand_id', 'Brand', 'required');
		}
		
		if ($this->form_validation->run() == TRUE)
		{
			$this->load->model('Item_model');
			$this->load->model('Posted_item_variance_model');
			$this->load->model('Tag_model');
			$this->Item_model->insert_from_post();
			$this->Posted_item_variance_model->insert_from_post($this->Item_model->id);
			$this->Tag_model->insert_from_post($this->Item_model->id);
			
			redirect('Item/post_item_list');
		}
	}
	
	public function upload_image($item_id, $index)
	{
		$data['error'] = array();
		$file_path = array();
		$this->load->config('upload');
		
		$config_upload_image = $this->config->item('upload_profpic');
		$config_upload_image['upload_path'] .= $this->session->account_id."/";
		$config_upload_image['file_name'] = $item_id."-".$index.".jpg";
		$this->load->library('upload', $config_upload_image);
		
		if ($_FILES['image_one_name']['name'])
		{
			if (!is_dir($config_upload_image['upload_path'])) {
				mkdir($config_upload_image['upload_path']);
			}
			if (!$this->upload->do_upload('image_one_name'))
			{
				$data['error'] = $this->upload->display_errors('', '');
			}
			else $file_path['image_one_name'] = $config_upload_image['upload_path'].$this->upload->data('file_name');
		}
		
		if (count($data['error']) == 0)
		{
			$this->load->model('Item_model');
			$this->Item_model->update_image($this->session->id, $file_path['image_one_name']);
			
			$data['image_url'] = site_url($file_path['image_one_name']);
		}
			
		header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
		header("Cache-Control: post-check=0, pre-check=0", false);
		header("Pragma: no-cache");
		header("Content-Type: application/json; charset=utf-8");
		echo json_encode($data);
	}
	
}
