<div class="cb-col-full cb-txt-primary-1 cb-font-title">
	<div class="cb-align-center cb-font-size-xl">DAFTAR</div>
</div>
<div class="cb-panel-body cb-bg-primary-3 cb-m-5 cb-p-5">
	<form action="<?=site_url('account/create_tenant')?>" class="form-horizontal" method="post" enctype="multipart/form-data">
		<div class="cb-row cb-col-full cb-txt-primary-1 cb-font-title cb-border-bottom">
			<div class="cb-align-center cb-font-size-xl">Pendaftaran Berhasil!</div>
		</div>
		<div class="cb-row cb-p-5">
			Silakan masuk menggunakan data yang didaftarkan
		</div>
	</div>
</div>

<?php /*
<div class="col-sm-8 col-sm-offset-2">
	<div class="panel panel-default">
		<div class="panel-heading">
			<h3>Sign Up</h3>
		</div>
		<div class="panel-body text-center">
			<h4>Sign Up Berhasil!</h4>
			Silakan login menggunakan data yang didaftarkan
		</div>
	</div>
</div>
*/ ?>