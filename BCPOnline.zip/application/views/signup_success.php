<div class="col-sm-8 col-sm-offset-2">
	<div class="panel panel-default">
		<div class="panel-heading">
			<h3>Sign Up</h3>
		</div>
		<div class="panel-body text-center">
			<h4>Sign Up Berhasil!</h4>
			Silakan login menggunakan data yang didaftarkan
		</div>
	</div>
</div>