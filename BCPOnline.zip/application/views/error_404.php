<div class="panel panel-default">
	<div class="panel-heading">
		<h3>Halaman Tidak Ditemukan</h3>
	</div>
	<div class="panel-body">
		Mohon maaf, halaman tidak ditemukan. Silakan kembali ke <a href="<?=site_url('dashboard')?>">Halaman Utama</a>.
	</div>
</div>