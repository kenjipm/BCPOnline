</div>
<!-- END OF BODY CONTAINER -->

<!-- Footer -->
<footer class="footer">
	<div class="container text-center">
		<span class="text-muted">Copyright &copy; <?=COMPANY_NAME?> 2017</span>
	</div>
	<!-- /.container -->
</footer>

</body>
</html>