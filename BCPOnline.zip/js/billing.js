function select_payment_method(name) {
	$("#payment_method-"+name).prop("checked", true);
}