function select_payment_method(id) {
	$("#payment_method-"+id).prop("checked", true);
}