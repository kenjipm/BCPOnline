function hot_item_do() {
	if (confirm("Ajukan produk untuk menjadi hot item?")) {
		$("#form-hot_item").submit();
	}
}