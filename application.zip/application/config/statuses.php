<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['REDEEM_REWARD'] = array(
	'name' => array(
		"PENDING"		=> "PENDING",
		"DONE"			=> "DONE",
	),
	'description' => array(
		"PENDING"		=> "Belum Diambil",
		"DONE"			=> "Sudah Diambil",
	),
);

?>