<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['RATIO_PERCENT_REPEAT'] = 2; // berapa kali ratio percent yg sama dipake lagi

?>