<div class="cb-col-full cb-p-5">
	<div class="cb-font-title cb-txt-primary-1 cb-font-size-xl"><?=$title?></div>
	<div class="cb-bg-secondary-3 cb-border-round cb-p-5">
	
		<?php /* Text */ ?>
		
		Lorem ipsum dolor sit amet, an vel sale graeco feugait, reprimique assueverit repudiandae mea at, salutandi imperdiet vix in. Vide copiosae rationibus vel et, usu te populo maiorum. At stet omnis simul mea, te sea sint dicunt deseruisse. Ut augue doming eum, persius interesset sit te, ut ius denique placerat.
		
		<br/>
		<br/>

		Vim an dolor interesset. An corrumpit prodesset sit. Id tota postulant vis, no qui tota alterum deseruisse. Sumo salutatus no has, eos quem illum ut. Cu vim epicurei ocurreret, semper honestatis cu ius.
		
		<br/>

		<ul>
			<li>Ex duo probo vocent posidonium.</li>
			<li>Paulo noster detracto mea ad.  </li>
			<li>Mei verterem cotidieque ex.    </li>
			<li>At nostro vituperatoribus sed. </li>
		</ul>

		Harum habemus epicurei sit no, duo et noster timeam commodo. Facilisi lobortis nec eu, dictas nominavi fabellas vis id, odio scaevola conclusionemque sea ne. At verterem dissentiet ius, malis aliquip has te. Ad detraxit quaerendum mei, in eum graecis abhorreant appellantur.
		
		<hr class="cb-border"/>

		Ea per vero docendi suscipiantur. Summo omnes consequat id mel. Vis ei epicuri repudiare posidonium, sed integre facilis officiis ne, qui ei ignota salutatus. Atqui nemore salutatus in vim, duo ea timeam concludaturque.
	
	</div>
</div>