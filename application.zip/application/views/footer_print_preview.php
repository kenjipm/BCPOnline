		</div>
		<!-- END OF PRINT CONTAINER -->
	</div>
	</div>
	<!-- END OF PANEL -->
</div>
<!-- END OF BODY CONTAINER -->

<footer class="footer">
	<div class="container text-center">
		<button type="button" class="cb-button-form" onclick="container_print()">CETAK</button>
	</div>
</footer>

<iframe name="print_frame" width="0" height="0" frameborder="0" src="about:blank"></iframe>

</body>
</html>